USE:
    https://buildroot.org/downloads/manual/manual.html#adding-packages


NOTE: 
    "whackamole" directory with sources needs to be just outside the buildroot folder.